This file include the details and URL of the Project created:

Screenshot1.png-It includes the step1 that is creation of Bucket.

Screenshot2.png-It includes the uploading of all the files.

Screenshot3.png-It includes the static website hosting selection.

Screenshot4.png-It includes the snap for bucket policy.

Screenshot5.png-It includes the snap for cloudFront Distributions.

Screenshot6.png-It includes the snap for website Hosting in browser


URL-http://rambohraa-website.s3.ap-south-1.amazonaws.com/index.html